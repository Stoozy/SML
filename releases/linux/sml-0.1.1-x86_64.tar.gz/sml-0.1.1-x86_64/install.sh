#!/bin/bash

cp -r sml /usr/local/bin
