#!/bin/bash

cp -v ./sml /usr/local/bin
